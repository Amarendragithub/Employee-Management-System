CREATE VIEW `x$host_summary` AS
  SELECT
    if((`performance_schema`.`accounts`.`HOST` IS NULL), 'background',
       `performance_schema`.`accounts`.`HOST`)                      AS `host`,
    sum(`sys`.`stmt`.`total`)                                       AS `statements`,
    sum(`sys`.`stmt`.`total_latency`)                               AS `statement_latency`,
    (sum(`sys`.`stmt`.`total_latency`) / sum(`sys`.`stmt`.`total`)) AS `statement_avg_latency`,
    sum(`sys`.`stmt`.`full_scans`)                                  AS `table_scans`,
    sum(`sys`.`io`.`ios`)                                           AS `file_ios`,
    sum(`sys`.`io`.`io_latency`)                                    AS `file_io_latency`,
    sum(`performance_schema`.`accounts`.`CURRENT_CONNECTIONS`)      AS `current_connections`,
    sum(`performance_schema`.`accounts`.`TOTAL_CONNECTIONS`)        AS `total_connections`,
    count(DISTINCT `performance_schema`.`accounts`.`USER`)          AS `unique_users`,
    sum(`sys`.`mem`.`current_allocated`)                            AS `current_memory`,
    sum(`sys`.`mem`.`total_allocated`)                              AS `total_memory_allocated`
  FROM (((`performance_schema`.`accounts`
    JOIN `sys`.`x$host_summary_by_statement_latency` `stmt`
      ON ((`performance_schema`.`accounts`.`HOST` = `sys`.`stmt`.`host`))) JOIN `sys`.`x$host_summary_by_file_io` `io`
      ON ((`performance_schema`.`accounts`.`HOST` = `sys`.`io`.`host`))) JOIN
    `sys`.`x$memory_by_host_by_current_bytes` `mem` ON ((`performance_schema`.`accounts`.`HOST` = `sys`.`mem`.`host`)))
  GROUP BY if((`performance_schema`.`accounts`.`HOST` IS NULL), 'background', `performance_schema`.`accounts`.`HOST`);
